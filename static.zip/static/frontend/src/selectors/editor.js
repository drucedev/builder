const {createSelector} = Reselect;

const editorState = state => state.editor;

export const isFullScreenMode = createSelector(
  editorState, editor => editor.fullScreenMode
);
