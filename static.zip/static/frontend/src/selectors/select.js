import config from "../config.js";
import {getCurrentUri} from "./router.js";
const {createSelector} = Reselect;

const selectState = state => state.select;

export const getSelectedId = createSelector(
  [getCurrentUri, selectState],
  (currentUri, select) => select[currentUri] || config.defaultRequestId
);

export const isDefaultRequest = createSelector(
  getSelectedId, selectedId => selectedId === config.defaultRequestId
);
