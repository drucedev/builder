import {component, div} from "../elements.js";
import NavigationBar from "./navigationBar/NavigationBar.js";
import FgServiceMethodPanel from "./fgServiceMethodPanel/FgServiceMethodPanel.js";
import HelpPage from "./helpPage/HelpPage.js";
const {Switch, Route} = ReactRouterDOM;

export default class FgServicesPage extends React.Component {
  render() {
    return div({},
      component(NavigationBar),
      component(Switch, {},
        component(Route, {path: '/:fgServiceName/:fgMethodName', component: FgServiceMethodPanel}),
        component(Route, {path: '/', component: HelpPage})
      )
    )
  }
}
