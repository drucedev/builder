import {component, div} from "../../../../elements.js";
import {changeSelected} from "../../../../../actions/tabs.js";
import {editRequest} from '../../../../../actions/requests.js';
import FgMethodEditor from "../fgMethodEditor/FgMethodEditor.js";
import {getDefaultRequestSchema} from "../../../../../selectors/requests.js";
import {isFullScreenMode} from "../../../../../selectors/editor.js";
import {toggleFullScreenMode} from "../../../../../actions/editor.js";
import {getSelectedTab} from "../../../../../selectors/tabs.js";
import {isDefaultRequest} from "../../../../../selectors/select.js";
import {getCurrentUri} from "../../../../../selectors/router.js";
const {connect} = ReactRedux;
const {Tabs, TabLink, TabContent} = ReactTabs;

class FgMethodRequestTabs extends React.Component {
  render() {
    const {
      isDefault,
      currentUri,
      currentRequest,
      requestSchema,
      changeSelected,
      toggleFullScreenMode,
      isFullScreenMode,
      selectedTab,
      editRequest
    } = this.props;
    return component(Tabs, {
        className: 'tabs tabs-1',
        handleSelect: tab => changeSelected(tab, currentUri, currentRequest.id),
        selectedTab
      },
      div({className: 'tab-links'},
        component(TabLink, {to: 'value'}, "Запрос"),
        component(TabLink, {to: 'schema'}, "Описание параметров"),
      ),
      div({className: 'content'},
        component(TabContent, {for: 'value'},
          component(FgMethodEditor, {
            value: currentRequest.value,
            options: {
              lint: true,
              autoCloseBrackets: true,
              readOnly: isDefault,
              fullScreen: isFullScreenMode
            },
            onToggleFullScreenMode: toggleFullScreenMode,
            onChange: value => editRequest(currentUri, {
              id: currentRequest.id,
              value
            })
          })
        ),
        component(TabContent, {for: 'schema'},
          component(FgMethodEditor, {
              value: requestSchema,
              options: {readOnly: true}
            }
          )
        )
      )
    );
  }
}

export default connect(
  state => ({
    isDefault: isDefaultRequest(state),
    isFullScreenMode: isFullScreenMode(state),
    requestSchema: getDefaultRequestSchema(state),
    selectedTab: getSelectedTab(state),
    currentUri: getCurrentUri(state)
  }),
  {
    changeSelected,
    editRequest,
    toggleFullScreenMode
  }
)(FgMethodRequestTabs);
