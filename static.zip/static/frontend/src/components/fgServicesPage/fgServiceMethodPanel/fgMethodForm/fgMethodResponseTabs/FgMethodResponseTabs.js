import {component, div} from "../../../../elements.js";
import FgMethodEditor from "../fgMethodEditor/FgMethodEditor.js";
const {Tabs, TabLink, TabContent} = ReactTabs;

export default class FgMethodResponseTabs extends React.Component {
  render() {
    return component(Tabs, {
        className: 'tabs tabs-1'
      },
      div({className: 'tab-links'},
        component(TabLink, {to: 'currentResponse'}, "Ответ"),
      ),
      div({className: 'content'},
        component(TabContent, {for: 'currentResponse'},
          component(FgMethodEditor, {
              value: this.props.response,
              options: {readOnly: true}
            }
          )
        )
      )
    )
  }
}
