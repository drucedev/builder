import FgSavedMethodRequestsSelectOption from "./FgSavedMethodRequestsSelectOption.js";
import {component} from "../../../../elements.js";
import {getCurrentRequestsValues} from "../../../../../selectors/requests.js";
import {changeSelected} from "../../../../../actions/select.js";
const {connect} = ReactRedux;

class FgSavedMethodRequestsSelect extends React.Component {
  render() {
    const {
      currentRequest,
      currentRequests,
      changeSelected,
      currentUri,
    } = this.props;
    return component(Select, {
      autosize: false,
      options: currentRequests,
      clearable: false,
      value: currentRequest,
      labelKey: 'name',
      onChange: selected => changeSelected(currentUri, selected.id),
      optionComponent: (props) => component(FgSavedMethodRequestsSelectOption, {
        currentUri,
        currentRequest,
        changeSelected,
        ...props
      })
    })
  }
}

export default connect(
  state => ({
    currentRequests: getCurrentRequestsValues(state)
  }),
  {
    changeSelected
  }
)(FgSavedMethodRequestsSelect)
