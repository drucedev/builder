import {a, li} from "../../../elements.js";
import {getCurrentUri} from "../../../../selectors/router.js";
const {connect} = ReactRedux;

class NavigationBarLabel extends React.Component {
  render() {
    const {currentUri} = this.props;

    return li({},
      a({}, currentUri)
    )
  }
}

export default connect(
  state => ({
    currentUri: getCurrentUri(state)
  })
)(NavigationBarLabel)
