import {div, label, component} from "../../../elements.js";
const {Link} = ReactRouterDOM;

export default class NavigationBarHeader extends React.Component {
  render() {
    return div({className: 'navbar-header'},
      label({className: 'navbar-brand'},
        component(Link, {to: '/'}, 'Api')
      )
    )
  }
}
