import {a, component, li, span, ul} from "../../../elements.js";
import NavigationBarDropdownSubMenu from "./NavigationBarDropdownSubMenu.js";
import {fetchBuilder} from "../../../../actions/requests.js";
const {connect} = ReactRedux;

class NavigationBarDropdown extends React.Component {
  constructor(props) {
    super(props);
    this.state = {fgServices: []};
  }

  componentWillMount() {
    this.props.fetchBuilder().then(fgServices => {
      this.setState({fgServices});
    })
  }

  componentDidMount() {
    new Dropdown(document.getElementById('service'), {persist: true});
  }

  render() {
    return li({className: 'dropdown'},
      a({
          id: 'service',
          role: 'button',
          className: 'dropdown-toggle',
          href: '#',
        },
        'Сервисы ',
        span({className: 'caret'})
      ),
      ul({
          className: 'dropdown-menu',
          role: 'menu'
        },
        this.state.fgServices.map(service => {
          return component(NavigationBarDropdownSubMenu, {service})
        })
      )
    )
  }
}

export default connect(
  null,
  {
    fetchBuilder
  }
)(NavigationBarDropdown);
