import FgServicesPage from "./fgServicesPage/FgServicesPage.js";
import {component, div} from "./elements.js";

export default class App extends React.Component {
  render() {
    return div({id: 'app-component'},
      component(FgServicesPage)
    )
  }
}
