export const TOGGLE_FULL_SCREEN_MODE = "editor/TOGGLE_FULL_SCREEN_MODE";
export const toggleFullScreenMode = () => ({
  type: TOGGLE_FULL_SCREEN_MODE
});
