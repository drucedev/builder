import App from "./components/App.js";
import {component} from "./components/elements.js";
import {loadState, saveState} from "./localStorage.js";
import {configureStore} from "./store.js";
const {Provider} = ReactRedux;
const {ConnectedRouter} = ConnectedReactRouter;
const {render} = ReactDOM;
const {createHashHistory} = History;

const history = createHashHistory();
const persistedState = loadState();

const store = configureStore(history, persistedState);

store.subscribe(() => saveState(store.getState()));

render(
  component(Provider, {store},
    component(ConnectedRouter, {history},
      component(App)
    )
  ),
  document.getElementById('root')
);
