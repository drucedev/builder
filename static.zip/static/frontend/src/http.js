import config from "./config.js";

export default axios.create({
  baseURL: config.backendUrl
});
