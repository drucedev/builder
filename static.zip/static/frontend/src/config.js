export default {
  defaultRequestId: 'default',
  defaultRequestName: 'Тестовый набор по умолчанию',
  defaultNewRequestName: 'Новый тестовый набор',
  backendUrl: 'http://localhost:8888/bfs-credit-request/rest',
  builderUri: '/builder.json',
}
