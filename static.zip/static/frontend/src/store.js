import rootReducer from './reducers/rootReducer.js';

const {createLogger} = reduxLogger;
const thunk = ReduxThunk;
const {createStore, compose, applyMiddleware} = Redux;
const {connectRouter, routerMiddleware} = ConnectedReactRouter;

export const configureStore = (history, initialState) => {
  const middlewares = [
    thunk.default,
    createLogger()
  ];

  const composeEnhancers = (typeof window === "object" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__) || compose;

  return createStore(
    connectRouter(history)(rootReducer),
    initialState, composeEnhancers(
    applyMiddleware(
      routerMiddleware(history),
      ...middlewares
    ),
  ));
};
