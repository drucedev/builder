function prettyJson(obj) {
  return JSON.stringify(obj, undefined, 4);
}

function getJsonLength(res) {
  return _.size(_.split(res, '\n'));
}
