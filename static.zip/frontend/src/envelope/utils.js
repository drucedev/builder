function prettyJson(obj) {
  return JSON.stringify(obj, undefined, 4);
}

function prepareJson(raw) {
  var obj = JSON.parse(raw);
  return JSON.stringify(obj);
}

function getJsonLength(raw) {
  return _.size(_.split(raw, '\n'));
}

function prepareErrorResponse(response) {
  return response
    .replace(/\\n\\tat|\\n/g, "\n")
    .replace(/\\\\\\"|\\"/g, "'");
}
