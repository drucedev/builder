var TEXTAREA_MAX_SIZE = 50;

var element = React.createElement;

var Envelope = React.createClass({
  updateVmState: function (vm, serviceAction, methodAction) {
    var services = _.map(vm.services, function (service) {
      if (serviceAction) {
        serviceAction(service);
      }
      var methods = _.map(service.methods, function (method) {
        if (methodAction) {
          return methodAction(service, method);
        }
        return method;
      });
      return _.assign({}, service, {methods: methods});
    });
    return _.assign({}, vm, {services: services});
  },

  updateMethodState: function (vm, service, method, updateAction) {
    return this.updateVmState(vm, function ($service) {
      if (service.name !== $service.name) {
        return $service;
      }
    }, function ($service, $method) {
      if (method.name !== $method.name) {
        return $method;
      }
      return updateAction($method);
    });
  },

  getInitialState: function () {
    var raw = localStorage.getItem('params');
    var params = raw ? JSON.parse(raw) : {};
    return {
      vm: {},
      params: params
    }
  },

  componentWillMount: function () {
    var self = this;
    var params = self.state.params;
    getVm().then(function ($vm) {
      var vm = self.updateVmState($vm, undefined, function (service, method) {
        var path = self.getPath(service, method);
        var request = params[path] || prettyJson(method.request);
        return _.assign({}, method, {request: request});
      });
      self.setState({vm: vm});
    });
  },

  getPath: function (service, method) {
    return service.name + '.' + method.name;
  },

  onChange: function (service, method, e) {
    var request = e.target.value;
    var vm = this.updateMethodState(this.state.vm, service, method, function (method) {
      return _.assign({}, method, {request: request})
    });
    this.setState({vm: vm});
  },

  onSave: function (service, method) {
    var params = this.state.params;
    var path = this.getPath(service, method);
    params[path] = method.request;
    localStorage.setItem('params', JSON.stringify(params));
  },

  onSend: function (service, method) {
    var self = this;
    send(service.name, method.name, prepareJson(method.request))
      .then(function (response) {
        return response.isError
          ? prepareErrorResponse(prettyJson(response.data))
          : prettyJson(response.data);
      })
      .then(function (response) {
        var vm = self.updateMethodState(self.state.vm, service, method, function (method) {
          return _.assign({}, method, {response: response})
        });
        self.setState({vm: vm});
      });
  },

  render: function () {
    var self = this;
    var vm = self.state.vm;
    var renderResetButton = element('button', {
        className: 'btn btn-sm btn-primary', style: {marginBottom: '10px'}, type: 'button', onClick: function () {
          localStorage.clear();
          location.reload();
        }
      },
      'Reset local cache with requests');
    var renderButtons = function (service, method) {
      return element('div', null,
        element('button', {className: 'btn btn-sm btn-primary btn-primary-spacing'}, 'Send'),
        element('button', {
            className: 'btn btn-sm btn-primary btn-primary-spacing', type: 'button',
            onClick: function () {
              self.onSave(service, method);
            }
          }, 'Save'
        )
      );
    };

    var renderMethod = function (service, method) {
      var requestLength = getJsonLength(method.request);
      var responseLength = getJsonLength(method.response);

      var requestTextAreaSize = requestLength > TEXTAREA_MAX_SIZE
        ? TEXTAREA_MAX_SIZE
        : requestLength;
      var responseTextAreaSize = (responseLength > TEXTAREA_MAX_SIZE)
        ? TEXTAREA_MAX_SIZE
        : responseLength;

      return element('form', {
          className: 'form-horizontal', onSubmit: function (e) {
            e.preventDefault();
            self.onSend(service, method)
          }
        },
        element('div', null,
          'Request', element('textArea', {
            className: 'form-control', style: {resize: 'none'}, rows: requestTextAreaSize, cols: 50,
            onChange: function (e) {
              self.onChange(service, method, e);
            }, value: method.request
          })
        ),
        element('div', null,
          'Response', element('textArea', {
            className: 'form-control', style: {resize: 'none'}, readOnly: true, rows: responseTextAreaSize, cols: 50,
            value: method.response
          })
        ),
        renderButtons(service, method)
      )
    };

    var renderMethods = function (service, methods) {
      return _.map(methods, function (method) {
        return element('div', {className: 'panel panel-default', key: method.name},
          element('div', {className: 'panel-heading'}, method.name),
          element('div', {className: 'panel-body'},
            renderMethod(service, method)
          )
        )
      })
    };

    var renderServices = _.map(vm.services, function (service) {
      return element('div', {className: 'panel panel-default', key: service.name},
        element('div', {className: 'panel-heading'}, service.name),
        element('div', {className: 'panel-body'},
          renderMethods(service, service.methods)
        )
      )
    });

    return element('div', {className: 'container'},
      renderResetButton,
      renderServices
    );
  }
});
