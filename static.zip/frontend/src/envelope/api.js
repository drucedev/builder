var apiUrl = root + '/rest';

function getVm() {
  return fetch(apiUrl + '/api')
    .then(function (response) {
      return response.json();
    })
    .then(function (services) {
      return {services: services};
    });
}

function send(serviceName, methodName, request) {
  var url = apiUrl + '/' + serviceName + '/' + methodName;
  return fetch(url, {
    headers: {
      'Content-Type': 'application/json'
    },
    method: 'POST',
    body: JSON.stringify(request)
  }).then(function (res) {
    return res.json()
  }).then(function (json) {
    return {
      data: json,
      isError: !!json.stackTrace
    }
  });
}
